(function(){
var inSheet=window.top!==window.self;
// Dans le panneau de la galerie : tout lien vers l'agenda ferme le panneau, et
// la galerie suit les changements de page (adresse affichée).
if(inSheet){try{parent.postMessage({evsheet:"page",path:location.pathname},location.origin)}catch(_){}}
document.querySelectorAll('a[href="/"]').forEach(function(a){a.addEventListener("click",function(e){
  if(inSheet){e.preventDefault();parent.postMessage({evsheet:"close"},location.origin);return}
  // Page ouverte seule : retour à la galerie telle qu'on l'a laissée si on en vient.
  try{var r=document.referrer&&new URL(document.referrer);if(r&&r.origin===location.origin&&history.length>1){e.preventDefault();history.back()}}catch(_){}})});
var m=document.querySelector("main[data-fav-key]");if(!m)return;var d=m.dataset;
function toast(t){var e=document.createElement("div");e.className="toast";e.textContent=t;document.body.appendChild(e);setTimeout(function(){e.remove()},2200)}
// Favoris : même stockage que la galerie (events-core.js, clé agenda-nancy:favoris).
var KEY="agenda-nancy:favoris";function load(){try{return JSON.parse(localStorage.getItem(KEY))||{}}catch(e){return{}}}
function save(f){try{localStorage.setItem(KEY,JSON.stringify(f))}catch(e){}}
var fav=document.querySelector(".js-fav");function paint(){var on=d.favKey in load();fav.setAttribute("aria-pressed",on);fav.querySelector("span").textContent=on?"Dans vos favoris":"Favori"}
if(fav){paint();fav.addEventListener("click",function(){var f=load();if(d.favKey in f)delete f[d.favKey];else f[d.favKey]=d.favEnd;save(f);paint()})}
// Ajouter à mon agenda : fichier .ics (Apple, Google, Outlook l'ouvrent tous).
var ics=document.querySelector(".js-ics");if(ics)ics.addEventListener("click",function(){
  function dt(day,t){return day.replace(/-/g,"")+(t?"T"+t.replace(":","")+"00":"")}
  var allDay=!d.time,end=d.end;if(allDay){var x=new Date(d.end+"T12:00:00");x.setDate(x.getDate()+1);end=x.toISOString().slice(0,10)}
  var endT=d.timeEnd||(d.time?String((parseInt(d.time,10)+2)%24).padStart(2,"0")+d.time.slice(2):"");
  var e=function(s){return String(s).replace(/([,;\\])/g,"\\$1")};
  var lines=["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//agenda-grandnancy.fr//FR","BEGIN:VEVENT","UID:"+d.url,"DTSTAMP:"+new Date().toISOString().replace(/[-:]/g,"").slice(0,15)+"Z",
    (allDay?"DTSTART;VALUE=DATE:":"DTSTART:")+dt(d.start,d.time),(allDay?"DTEND;VALUE=DATE:":"DTEND:")+dt(d.time?d.start:end,d.time?endT:""),
    "SUMMARY:"+e(d.title),"LOCATION:"+e(d.place),"URL:"+d.url,"END:VEVENT","END:VCALENDAR"];
  var b=new Blob([lines.join("\r\n")],{type:"text/calendar"});var a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="evenement.ics";document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500)});
// Partager : feuille de partage du téléphone, sinon copie du lien.
var sh=document.querySelector(".js-share");if(sh)sh.addEventListener("click",function(){
  if(navigator.share){navigator.share({title:d.title,url:d.url}).catch(function(){})}
  else if(navigator.clipboard){navigator.clipboard.writeText(d.url).then(function(){toast("Lien copié")})}
  else{prompt("Lien de la page",d.url)}});
})();
